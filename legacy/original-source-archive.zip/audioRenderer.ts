/**
 * Server-side audio rendering for high-fidelity export.
 * Generates WAV audio buffers from engine configurations and uploads to storage.
 */
import { updateExportJob } from "./db";
import { storagePut } from "./storage";

interface EngineConfig {
  quick: {
    layout: string;
    cylinderCount: number;
    displacement: number;
    crankshaft: string;
    aspiration: string;
    exhaustCharacter: string;
    idleCharacter: string;
    redline: number;
  };
  advanced?: {
    firingOrder?: number[];
    revLimiterType?: string;
    revLimiterRpm?: number;
  };
  forcedInduction: {
    type: string;
    turbo?: any;
    supercharger?: any;
  };
  seed?: number;
}

/**
 * Render an engine configuration to audio and upload to storage.
 * This is designed to run asynchronously after the job is created.
 */
export async function renderAndUpload(
  jobId: number,
  config: EngineConfig,
  format: 'wav' | 'mp3',
  durationSec: number
): Promise<void> {
  try {
    await updateExportJob(jobId, { status: 'rendering' });

    // Generate PCM audio data
    const sampleRate = 44100;
    const numChannels = 2;
    const length = Math.floor(sampleRate * durationSec);

    const { left, right } = generateEngineAudio(config, length, sampleRate);

    // Normalize
    let maxAmp = 0;
    for (let i = 0; i < length; i++) {
      maxAmp = Math.max(maxAmp, Math.abs(left[i]), Math.abs(right[i]));
    }
    if (maxAmp > 0 && maxAmp < 0.95) {
      const gain = 0.95 / maxAmp;
      for (let i = 0; i < length; i++) {
        left[i] *= gain;
        right[i] *= gain;
      }
    }

    // Encode to WAV
    const wavBuffer = encodeWav(left, right, sampleRate, numChannels);

    // Upload to storage
    const filename = `exports/engine-${config.quick.layout}-${config.quick.cylinderCount}cyl-${jobId}.wav`;
    const { url } = await storagePut(filename, Buffer.from(wavBuffer), 'audio/wav');

    await updateExportJob(jobId, {
      status: 'completed',
      fileUrl: url,
      fileKey: filename,
      completedAt: new Date(),
    });
  } catch (error: any) {
    await updateExportJob(jobId, {
      status: 'failed',
      errorMessage: error.message || 'Unknown error',
    });
    throw error;
  }
}

/**
 * Generate engine audio PCM data server-side.
 * This mirrors the client-side offline rendering logic.
 */
function generateEngineAudio(
  config: EngineConfig,
  length: number,
  sampleRate: number
): { left: Float32Array; right: Float32Array } {
  const left = new Float32Array(length);
  const right = new Float32Array(length);

  const { quick } = config;
  const firingIntervals = calculateFiringIntervals(
    quick.cylinderCount, quick.crankshaft, quick.layout
  );

  let crankAngle = 0;
  let nextFireTime = firingIntervals[0];
  let currentCylinder = 0;
  let timeSinceLastFire = 0;
  let seed = config.seed || 42;

  const startRpm = 800;
  const rampRate = (quick.redline - startRpm) / (length * 0.8);
  let currentRpm = startRpm;

  for (let i = 0; i < length; i++) {
    // Ramp RPM: 0-80% ramp up, 80-100% ramp down
    if (i < length * 0.8) {
      currentRpm = Math.min(quick.redline, startRpm + rampRate * i);
    } else {
      currentRpm = Math.max(startRpm, currentRpm - rampRate * 0.5);
    }

    const samplesPerRev = (60 * sampleRate) / currentRpm;
    const degreesPerSample = 720 / samplesPerRev;

    crankAngle += degreesPerSample;
    timeSinceLastFire += 1 / sampleRate;

    // Fire cylinder
    if (crankAngle >= nextFireTime) {
      currentCylinder = (currentCylinder + 1) % quick.cylinderCount;
      nextFireTime += firingIntervals[currentCylinder % firingIntervals.length];
      timeSinceLastFire = 0;
    }

    if (crankAngle >= 720) {
      crankAngle -= 720;
      nextFireTime -= 720;
    }

    // Combustion pulse
    const t = timeSinceLastFire;
    const throttle = Math.min(1, currentRpm / quick.redline);
    const pulseDecay = 0.001 + 0.002 * (1 - throttle);
    const pulseIntensity = 0.3 + 0.7 * throttle;
    const pulse = Math.exp(-t / pulseDecay) * pulseIntensity;

    // Harmonics
    const freq = currentRpm / 60;
    const phase = i * freq * 2 * Math.PI / sampleRate;
    const harmonics = Math.sin(phase) * 0.3 + Math.sin(phase * 2) * 0.2 + Math.sin(phase * 0.5) * 0.4;

    let sample = pulse * (0.5 + harmonics * 0.5);

    // Exhaust character filter simulation
    const exhaustFactor = quick.exhaustCharacter === 'straight-pipe' ? 1.2 :
                          quick.exhaustCharacter === 'race' ? 1.0 :
                          quick.exhaustCharacter === 'sport' ? 0.8 : 0.5;
    sample *= exhaustFactor;

    // Mechanical noise (deterministic PRNG)
    seed = (seed * 1664525 + 1013904223) & 0xFFFFFFFF;
    const noise = ((seed >>> 0) / 4294967296 - 0.5) * 0.02;
    sample += noise;

    // Forced induction contribution
    if (config.forcedInduction.type === 'turbo') {
      const boostFactor = throttle * 0.15;
      const turboFreq = 2000 + currentRpm * 0.5;
      sample += Math.sin(i * turboFreq * 2 * Math.PI / sampleRate) * boostFactor * 0.1;
    } else if (config.forcedInduction.type === 'supercharged') {
      const scFreq = currentRpm * 2;
      sample += Math.sin(i * scFreq * 2 * Math.PI / sampleRate) * 0.08;
    }

    // Soft clip with tanh
    sample = Math.tanh(sample * 1.5) * 0.8;

    left[i] = sample;
    right[i] = sample * 0.95 + noise * 0.05;
  }

  return { left, right };
}

/**
 * Calculate firing intervals based on engine configuration.
 */
function calculateFiringIntervals(
  cylinderCount: number,
  crankshaft: string,
  layout: string
): number[] {
  const evenInterval = 720 / cylinderCount;

  if (crankshaft === 'even-fire' || crankshaft === 'flat-plane') {
    return Array(cylinderCount).fill(evenInterval);
  }

  if (crankshaft === 'cross-plane' && cylinderCount === 8) {
    // Classic cross-plane V8 firing pattern
    return [90, 90, 90, 90, 90, 90, 90, 90];
  }

  if (crankshaft === 'odd-fire') {
    // Odd-fire creates uneven intervals
    const intervals: number[] = [];
    for (let i = 0; i < cylinderCount; i++) {
      intervals.push(i % 2 === 0 ? evenInterval * 0.8 : evenInterval * 1.2);
    }
    return intervals;
  }

  return Array(cylinderCount).fill(evenInterval);
}

/**
 * Encode PCM data to WAV format.
 */
function encodeWav(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number,
  numChannels: number
): ArrayBuffer {
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  const length = left.length;
  const dataSize = length * blockAlign;
  const headerSize = 44;
  const totalSize = headerSize + dataSize;

  const buffer = new ArrayBuffer(totalSize);
  const view = new DataView(buffer);

  // RIFF header
  writeString(view, 0, 'RIFF');
  view.setUint32(4, totalSize - 8, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);
  writeString(view, 36, 'data');
  view.setUint32(40, dataSize, true);

  // Interleave and write samples
  let offset = 44;
  for (let i = 0; i < length; i++) {
    // Left channel - clip protection
    let sampleL = Math.max(-1, Math.min(1, left[i]));
    view.setInt16(offset, sampleL < 0 ? sampleL * 0x8000 : sampleL * 0x7FFF, true);
    offset += 2;

    // Right channel - clip protection
    let sampleR = Math.max(-1, Math.min(1, right[i]));
    view.setInt16(offset, sampleR < 0 ? sampleR * 0x8000 : sampleR * 0x7FFF, true);
    offset += 2;
  }

  return buffer;
}

function writeString(view: DataView, offset: number, str: string): void {
  for (let i = 0; i < str.length; i++) {
    view.setUint8(offset + i, str.charCodeAt(i));
  }
}
