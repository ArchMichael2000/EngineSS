import { useState, useCallback, useRef, useEffect } from 'react';
import { getAudioEngine, AudioEngine } from '@/lib/audioEngine';
import type { EngineConfiguration, PlaybackState } from '../../../shared/engineTypes';
import { DEFAULT_ENGINE_CONFIG } from '../../../shared/engineTypes';

export function useAudioEngine() {
  const engineRef = useRef<AudioEngine | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [playbackState, setPlaybackState] = useState<PlaybackState>({
    isPlaying: false,
    rpm: 800,
    throttle: 0,
    load: 0.1,
    targetRpm: 800,
    boost: 0,
  });
  const [config, setConfig] = useState<EngineConfiguration>(DEFAULT_ENGINE_CONFIG);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    engineRef.current = getAudioEngine();
    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, []);

  const startStatePolling = useCallback(() => {
    const poll = () => {
      if (engineRef.current) {
        const state = engineRef.current.getState();
        setPlaybackState(state);
        setIsPlaying(state.isPlaying);
      }
      animFrameRef.current = requestAnimationFrame(poll);
    };
    animFrameRef.current = requestAnimationFrame(poll);
  }, []);

  const stopStatePolling = useCallback(() => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
  }, []);

  const initialize = useCallback(async () => {
    if (!engineRef.current) return;
    await engineRef.current.initialize();
    setIsInitialized(true);
  }, []);

  const startEngine = useCallback(async () => {
    if (!engineRef.current) return;
    if (!isInitialized) {
      await initialize();
    }
    engineRef.current.setConfig(config);
    await engineRef.current.start();
    setIsPlaying(true);
    startStatePolling();
  }, [config, isInitialized, initialize, startStatePolling]);

  const stopEngine = useCallback(() => {
    if (!engineRef.current) return;
    engineRef.current.stop();
    setIsPlaying(false);
    stopStatePolling();
    setPlaybackState(prev => ({ ...prev, isPlaying: false, rpm: 0 }));
  }, [stopStatePolling]);

  const setThrottle = useCallback((value: number) => {
    if (!engineRef.current) return;
    engineRef.current.setThrottle(value);
  }, []);

  const setRPM = useCallback((value: number) => {
    if (!engineRef.current) return;
    engineRef.current.setRPM(value);
  }, []);

  const setLoad = useCallback((value: number) => {
    if (!engineRef.current) return;
    engineRef.current.setLoad(value);
  }, []);

  const updateConfig = useCallback((newConfig: EngineConfiguration) => {
    setConfig(newConfig);
    if (engineRef.current && isPlaying) {
      engineRef.current.setConfig(newConfig);
    }
  }, [isPlaying]);

  const triggerBOV = useCallback(() => {
    if (!engineRef.current) return;
    engineRef.current.triggerBOV();
  }, []);

  return {
    isPlaying,
    isInitialized,
    playbackState,
    config,
    startEngine,
    stopEngine,
    setThrottle,
    setRPM,
    setLoad,
    updateConfig,
    triggerBOV,
    engine: engineRef.current,
  };
}
