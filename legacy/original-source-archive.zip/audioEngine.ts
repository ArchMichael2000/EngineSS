/**
 * Engine Sound Simulator - Hybrid Audio Engine
 * 
 * Combines procedural combustion pulse synthesis with sample-based texture layers.
 * Uses Web Audio API for real-time, seamless parameter changes.
 */

import type {
  EngineConfiguration,
  PlaybackState,
  EngineLayout,
  CrankshaftType,
} from '../../../shared/engineTypes';
import { getDefaultFiringOrder } from '../../../shared/engineTypes';

// ============================================================
// Audio Worklet Processor (inline as string for registration)
// ============================================================

const COMBUSTION_PROCESSOR_CODE = `
class CombustionProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.phase = 0;
    this.rpm = 800;
    this.throttle = 0;
    this.load = 0.1;
    this.cylinderCount = 8;
    this.firingIntervals = [];
    this.currentCylinder = 0;
    this.timeSinceLastFire = 0;
    this.nextFireTime = 0;
    this.crankAngle = 0;
    this.exhaustCharacter = 0.5;
    this.idleVariation = 0.02;
    this.seed = 12345;
    this.sampleIndex = 0;
    
    this.port.onmessage = (e) => {
      const d = e.data;
      if (d.rpm !== undefined) this.rpm = d.rpm;
      if (d.throttle !== undefined) this.throttle = d.throttle;
      if (d.load !== undefined) this.load = d.load;
      if (d.cylinderCount !== undefined) this.cylinderCount = d.cylinderCount;
      if (d.firingIntervals !== undefined) this.firingIntervals = d.firingIntervals;
      if (d.exhaustCharacter !== undefined) this.exhaustCharacter = d.exhaustCharacter;
      if (d.idleVariation !== undefined) this.idleVariation = d.idleVariation;
      if (d.seed !== undefined) this.seed = d.seed;
    };
  }

  // Simple seeded pseudo-random
  random() {
    this.seed = (this.seed * 1664525 + 1013904223) & 0xFFFFFFFF;
    return (this.seed >>> 0) / 4294967296;
  }

  process(inputs, outputs, parameters) {
    const output = outputs[0];
    const channel = output[0];
    if (!channel) return true;

    const sampleRate = sampleRate || 44100;
    const samplesPerRevolution = (60 * sampleRate) / Math.max(this.rpm, 100);
    const degreesPerSample = 720 / samplesPerRevolution; // 720 degrees for 4-stroke
    
    const intervals = this.firingIntervals.length > 0 
      ? this.firingIntervals 
      : this.getEvenIntervals();

    for (let i = 0; i < channel.length; i++) {
      this.crankAngle += degreesPerSample;
      this.timeSinceLastFire += 1 / sampleRate;

      let sample = 0;

      // Check if we should fire next cylinder
      if (this.crankAngle >= this.nextFireTime) {
        this.currentCylinder = (this.currentCylinder + 1) % this.cylinderCount;
        const interval = intervals[this.currentCylinder % intervals.length];
        this.nextFireTime += interval;
        this.timeSinceLastFire = 0;
      }

      // Wrap crank angle
      if (this.crankAngle >= 720) {
        this.crankAngle -= 720;
        this.nextFireTime -= 720;
      }

      // Generate combustion pulse
      const t = this.timeSinceLastFire;
      const pulseDecay = 0.001 + 0.002 * (1 - this.throttle);
      const pulseIntensity = 0.3 + 0.7 * (this.throttle * 0.7 + this.load * 0.3);
      
      // Combustion pulse shape: sharp attack, exponential decay
      const pulse = Math.exp(-t / pulseDecay) * pulseIntensity;
      
      // Add harmonic content based on exhaust character
      const freq = this.rpm / 60;
      const harmonicPhase = this.sampleIndex * freq * 2 * Math.PI / sampleRate;
      const harmonics = Math.sin(harmonicPhase) * 0.3 
        + Math.sin(harmonicPhase * 2) * 0.2 * this.exhaustCharacter
        + Math.sin(harmonicPhase * 3) * 0.1 * this.exhaustCharacter
        + Math.sin(harmonicPhase * 0.5) * 0.4; // Sub-harmonic for body

      sample += pulse * (0.5 + harmonics * 0.5);

      // Add idle variation
      if (this.rpm < 1200) {
        const idleNoise = (this.random() - 0.5) * this.idleVariation * (1200 - this.rpm) / 400;
        sample += idleNoise;
      }

      // Mechanical texture noise
      const mechNoise = (this.random() - 0.5) * 0.02 * (0.3 + this.rpm / 10000);
      sample += mechNoise;

      // Soft clip
      sample = Math.tanh(sample * 1.5) * 0.8;

      channel[i] = sample;
      this.sampleIndex++;
    }

    return true;
  }

  getEvenIntervals() {
    const interval = 720 / this.cylinderCount;
    return Array(this.cylinderCount).fill(interval);
  }
}

registerProcessor('combustion-processor', CombustionProcessor);
`;

// ============================================================
// Main Audio Engine Class
// ============================================================

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private combustionNode: AudioWorkletNode | null = null;
  private exhaustFilter: BiquadFilterNode | null = null;
  private intakeFilter: BiquadFilterNode | null = null;
  private reverbNode: ConvolverNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  
  // Forced induction nodes
  private turboOsc: OscillatorNode | null = null;
  private turboGain: GainNode | null = null;
  private superchargerOsc: OscillatorNode | null = null;
  private superchargerGain: GainNode | null = null;
  private bovGain: GainNode | null = null;
  
  // State
  private config: EngineConfiguration | null = null;
  private state: PlaybackState = {
    isPlaying: false,
    rpm: 800,
    throttle: 0,
    load: 0.1,
    targetRpm: 800,
    boost: 0,
  };
  
  private rpmSmoothing = 0.95;
  private animationFrame: number | null = null;
  private workletReady = false;
  private isInitialized = false;

  // For recording/export
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];
  private destinationNode: MediaStreamAudioDestinationNode | null = null;

  // Analyser for real waveform visualization
  private analyserNode: AnalyserNode | null = null;

  async initialize(): Promise<void> {
    if (this.isInitialized) return;
    
    this.ctx = new AudioContext({ sampleRate: 44100 });
    
    // Create the audio worklet
    const blob = new Blob([COMBUSTION_PROCESSOR_CODE], { type: 'application/javascript' });
    const url = URL.createObjectURL(blob);
    
    try {
      await this.ctx.audioWorklet.addModule(url);
      this.workletReady = true;
    } catch (e) {
      console.warn('AudioWorklet not supported, falling back to ScriptProcessor');
      this.workletReady = false;
    } finally {
      URL.revokeObjectURL(url);
    }

    this.setupAudioGraph();
    this.isInitialized = true;
  }

  private setupAudioGraph(): void {
    if (!this.ctx) return;

    // Master output chain
    this.compressor = this.ctx.createDynamicsCompressor();
    this.compressor.threshold.value = -6;
    this.compressor.knee.value = 10;
    this.compressor.ratio.value = 4;
    this.compressor.attack.value = 0.003;
    this.compressor.release.value = 0.1;

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.7;

    // Exhaust filter (low-pass for muffled exhaust character)
    this.exhaustFilter = this.ctx.createBiquadFilter();
    this.exhaustFilter.type = 'lowpass';
    this.exhaustFilter.frequency.value = 2000;
    this.exhaustFilter.Q.value = 1.5;

    // Intake filter (band-pass for intake roar)
    this.intakeFilter = this.ctx.createBiquadFilter();
    this.intakeFilter.type = 'bandpass';
    this.intakeFilter.frequency.value = 800;
    this.intakeFilter.Q.value = 0.8;

    // Reverb for spatial character
    this.reverbNode = this.ctx.createConvolver();
    this.generateReverbIR();

    // Turbo oscillator (whine)
    this.turboOsc = this.ctx.createOscillator();
    this.turboOsc.type = 'sine';
    this.turboOsc.frequency.value = 0;
    this.turboGain = this.ctx.createGain();
    this.turboGain.gain.value = 0;
    this.turboOsc.connect(this.turboGain);
    this.turboOsc.start();

    // Supercharger oscillator (whine with harmonics)
    this.superchargerOsc = this.ctx.createOscillator();
    this.superchargerOsc.type = 'sawtooth';
    this.superchargerOsc.frequency.value = 0;
    this.superchargerGain = this.ctx.createGain();
    this.superchargerGain.gain.value = 0;
    this.superchargerOsc.connect(this.superchargerGain);
    this.superchargerOsc.start();

    // BOV noise burst
    this.bovGain = this.ctx.createGain();
    this.bovGain.gain.value = 0;

    // For recording
    this.destinationNode = this.ctx.createMediaStreamDestination();

    // Analyser for waveform/spectrum visualization
    this.analyserNode = this.ctx.createAnalyser();
    this.analyserNode.fftSize = 2048;
    this.analyserNode.smoothingTimeConstant = 0.8;

    // Connect graph
    this.masterGain.connect(this.compressor);
    this.compressor.connect(this.ctx.destination);
    this.compressor.connect(this.destinationNode);
    this.compressor.connect(this.analyserNode);
    
    this.turboGain.connect(this.masterGain);
    this.superchargerGain.connect(this.masterGain);
    this.bovGain.connect(this.masterGain);
  }

  private generateReverbIR(): void {
    if (!this.ctx || !this.reverbNode) return;
    
    const length = this.ctx.sampleRate * 0.3; // 300ms reverb
    const buffer = this.ctx.createBuffer(2, length, this.ctx.sampleRate);
    
    for (let ch = 0; ch < 2; ch++) {
      const data = buffer.getChannelData(ch);
      for (let i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (length * 0.3));
      }
    }
    
    this.reverbNode.buffer = buffer;
  }

  setConfig(config: EngineConfiguration): void {
    this.config = config;
    // Ensure deterministic seed for reproducibility
    if (!this.config.seed) {
      this.config.seed = 42;
    }
    this.updateAudioParameters();
  }

  private updateAudioParameters(): void {
    if (!this.config || !this.ctx) return;

    const { quick, forcedInduction, advanced } = this.config;
    
    // Calculate firing intervals from config
    const firingOrder = advanced?.firingOrder || 
      getDefaultFiringOrder(quick.layout, quick.cylinderCount, quick.crankshaft);
    
    const firingIntervals = this.calculateFiringIntervals(
      quick.cylinderCount,
      quick.crankshaft,
      quick.layout
    );

    // Update exhaust filter based on character
    if (this.exhaustFilter) {
      const freqMap: Record<string, number> = {
        'stock': 1200,
        'sport': 2500,
        'race': 4000,
        'straight-pipe': 8000,
      };
      const targetFreq = freqMap[quick.exhaustCharacter] || 2000;
      this.exhaustFilter.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.05);
    }

    // Update intake filter
    if (this.intakeFilter) {
      const intakeFreqMap: Record<string, number> = {
        'single-throttle-body': 600,
        'itbs': 1200,
        'carb': 800,
        'velocity-stacks': 1500,
        'airbox': 500,
      };
      const intakeType = advanced?.intakeType || 'single-throttle-body';
      this.intakeFilter.frequency.setTargetAtTime(
        intakeFreqMap[intakeType] || 800, 
        this.ctx.currentTime, 
        0.05
      );
    }

    // Send parameters to worklet
    if (this.combustionNode) {
      this.combustionNode.port.postMessage({
        cylinderCount: quick.cylinderCount,
        firingIntervals,
        exhaustCharacter: quick.exhaustCharacter === 'race' ? 0.9 : 
                         quick.exhaustCharacter === 'sport' ? 0.6 : 
                         quick.exhaustCharacter === 'straight-pipe' ? 1.0 : 0.3,
        idleVariation: quick.idleCharacter === 'lopey' ? 0.06 :
                      quick.idleCharacter === 'aggressive' ? 0.04 :
                      quick.idleCharacter === 'lumpy' ? 0.03 : 0.01,
        seed: this.config.seed || Math.floor(Math.random() * 100000),
      });
    }
  }

  private calculateFiringIntervals(
    cylinderCount: number,
    crankshaft: CrankshaftType,
    layout: EngineLayout
  ): number[] {
    const totalDegrees = 720; // 4-stroke = 2 revolutions
    
    if (crankshaft === 'even-fire') {
      const interval = totalDegrees / cylinderCount;
      return Array(cylinderCount).fill(interval);
    }
    
    if (crankshaft === 'cross-plane' && cylinderCount === 8) {
      // Classic cross-plane V8: uneven firing creates the burble
      return [90, 90, 90, 90, 90, 90, 90, 90];
    }
    
    if (crankshaft === 'flat-plane' && cylinderCount === 8) {
      // Flat-plane V8: even 90-degree intervals
      return [90, 90, 90, 90, 90, 90, 90, 90];
    }
    
    if (crankshaft === 'odd-fire') {
      // Odd-fire creates uneven intervals for character
      const baseInterval = totalDegrees / cylinderCount;
      return Array(cylinderCount).fill(0).map((_, i) => 
        baseInterval + (i % 2 === 0 ? 15 : -15)
      );
    }
    
    // Default even fire
    const interval = totalDegrees / cylinderCount;
    return Array(cylinderCount).fill(interval);
  }

  async start(): Promise<void> {
    if (!this.ctx) await this.initialize();
    if (!this.ctx) return;

    if (this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }

    // Create combustion source
    if (this.workletReady && !this.combustionNode) {
      this.combustionNode = new AudioWorkletNode(this.ctx, 'combustion-processor');
      
      // Connect through filters
      const exhaustGain = this.ctx.createGain();
      exhaustGain.gain.value = 0.7;
      const intakeGain = this.ctx.createGain();
      intakeGain.gain.value = 0.3;

      this.combustionNode.connect(this.exhaustFilter!);
      this.combustionNode.connect(this.intakeFilter!);
      this.exhaustFilter!.connect(exhaustGain);
      this.intakeFilter!.connect(intakeGain);
      exhaustGain.connect(this.masterGain!);
      intakeGain.connect(this.masterGain!);

      this.updateAudioParameters();
    } else if (!this.workletReady) {
      // Fallback: use oscillator-based synthesis
      this.startFallbackSynthesis();
    }

    this.state.isPlaying = true;
    this.state.rpm = 800;
    this.state.targetRpm = 800;
    this.startUpdateLoop();
  }

  private startFallbackSynthesis(): void {
    if (!this.ctx || !this.masterGain) return;
    
    // Simple oscillator-based fallback for browsers without AudioWorklet
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.value = 80;
    gain.gain.value = 0.3;
    osc.connect(gain);
    gain.connect(this.exhaustFilter!);
    this.exhaustFilter!.connect(this.masterGain);
    osc.start();
  }

  stop(): void {
    this.state.isPlaying = false;
    
    if (this.combustionNode) {
      this.combustionNode.disconnect();
      this.combustionNode = null;
    }
    
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
    }

    if (this.ctx && this.ctx.state === 'running') {
      this.ctx.suspend();
    }
  }

  private revLimiterActive = false;
  private revLimiterCooldown = 0;

  private startUpdateLoop(): void {
    const update = () => {
      if (!this.state.isPlaying) return;

      // Rev limiter behavior
      if (this.config) {
        const limiterRpm = this.config.advanced?.revLimiterRpm || this.config.quick.redline;
        const limiterType = this.config.advanced?.revLimiterType || 'hard-fuel-cut';

        if (this.state.rpm >= limiterRpm - 50) {
          if (limiterType === 'hard-fuel-cut' || limiterType === 'hard-ignition-cut') {
            // Hard cut: abruptly drop RPM then allow back up (creates the characteristic stutter)
            if (!this.revLimiterActive) {
              this.revLimiterActive = true;
              this.revLimiterCooldown = 8; // frames of cut
            }
            if (this.revLimiterCooldown > 0) {
              this.state.targetRpm = limiterRpm - 200;
              this.revLimiterCooldown--;
              // Momentarily cut volume for hard-cut effect
              if (this.masterGain && this.ctx) {
                this.masterGain.gain.setTargetAtTime(
                  limiterType === 'hard-fuel-cut' ? 0.1 : 0.3,
                  this.ctx.currentTime, 0.005
                );
              }
            } else {
              this.revLimiterActive = false;
              if (this.masterGain && this.ctx) {
                this.masterGain.gain.setTargetAtTime(0.7, this.ctx.currentTime, 0.01);
              }
            }
          } else {
            // Soft limiter: gradually reduce power near redline
            const overRev = (this.state.rpm - (limiterRpm - 200)) / 200;
            this.state.targetRpm = Math.min(this.state.targetRpm, limiterRpm - overRev * 100);
          }
        } else {
          this.revLimiterActive = false;
        }
      }

      // Smooth RPM transitions (engine inertia)
      const rpmDiff = this.state.targetRpm - this.state.rpm;
      const inertia = Math.abs(rpmDiff) > 500 ? 0.92 : 0.96;
      this.state.rpm += rpmDiff * (1 - inertia);

      // Update audio nodes with current RPM
      this.updateRealtime();

      this.animationFrame = requestAnimationFrame(update);
    };
    
    this.animationFrame = requestAnimationFrame(update);
  }

  private updateRealtime(): void {
    if (!this.ctx || !this.config) return;

    const { rpm, throttle, load } = this.state;
    const { forcedInduction } = this.config;

    // Update combustion worklet
    if (this.combustionNode) {
      this.combustionNode.port.postMessage({ rpm, throttle, load });
    }

    // Update exhaust filter resonance with RPM
    if (this.exhaustFilter) {
      const baseFreq = this.config.quick.exhaustCharacter === 'straight-pipe' ? 8000 :
                       this.config.quick.exhaustCharacter === 'race' ? 4000 :
                       this.config.quick.exhaustCharacter === 'sport' ? 2500 : 1200;
      const rpmFactor = 1 + (rpm / this.config.quick.redline) * 0.5;
      this.exhaustFilter.frequency.setTargetAtTime(
        baseFreq * rpmFactor, 
        this.ctx.currentTime, 
        0.02
      );
    }

    // Forced induction sounds
    if (forcedInduction.type === 'turbo') {
      this.updateTurboSound(rpm, throttle);
    } else if (forcedInduction.type === 'supercharged') {
      this.updateSuperchargerSound(rpm);
    }
  }

  private updateTurboSound(rpm: number, throttle: number): void {
    if (!this.ctx || !this.turboOsc || !this.turboGain || !this.config) return;

    const fi = this.config.forcedInduction;
    const spoolThreshold = fi.turboSpoolThreshold || 3000;
    const turboSize = fi.turboSize || 'balanced';
    
    // Spool behavior based on size
    const spoolRate = turboSize === 'small' ? 0.8 : turboSize === 'large' ? 0.3 : 0.5;
    
    if (rpm > spoolThreshold && throttle > 0.3) {
      const spoolProgress = Math.min(1, (rpm - spoolThreshold) / 3000 * spoolRate);
      const turboFreq = 2000 + spoolProgress * 6000; // 2-8kHz whine
      const turboVol = spoolProgress * 0.08 * throttle;
      
      this.turboOsc.frequency.setTargetAtTime(turboFreq, this.ctx.currentTime, 0.1);
      this.turboGain.gain.setTargetAtTime(turboVol, this.ctx.currentTime, 0.05);
      
      // Update boost state
      this.state.boost = spoolProgress * (fi.maxBoost || 15);
    } else {
      this.turboGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.2);
      this.state.boost = Math.max(0, this.state.boost - 0.5);
    }
  }

  private updateSuperchargerSound(rpm: number): void {
    if (!this.ctx || !this.superchargerOsc || !this.superchargerGain || !this.config) return;

    const fi = this.config.forcedInduction;
    const whineIntensity = fi.whineIntensity || 0.5;
    
    // Supercharger is mechanically driven - always proportional to RPM
    const rpmNormalized = rpm / (this.config.quick.redline || 7000);
    const scFreq = 1000 + rpmNormalized * 8000;
    const scVol = rpmNormalized * 0.06 * whineIntensity;
    
    this.superchargerOsc.frequency.setTargetAtTime(scFreq, this.ctx.currentTime, 0.02);
    this.superchargerGain.gain.setTargetAtTime(scVol, this.ctx.currentTime, 0.02);
    
    this.state.boost = rpmNormalized * (fi.superchargerBoost || 10);
  }

  // Trigger BOV sound (blow-off valve)
  triggerBOV(): void {
    if (!this.ctx || !this.bovGain || !this.config) return;
    if (this.config.forcedInduction.type !== 'turbo') return;
    if (!this.config.forcedInduction.bovEnabled) return;

    // Create noise burst for BOV
    const bufferSize = this.ctx.sampleRate * 0.3;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    
    for (let i = 0; i < bufferSize; i++) {
      const envelope = Math.exp(-i / (bufferSize * 0.15));
      data[i] = (Math.random() * 2 - 1) * envelope;
    }
    
    const source = this.ctx.createBufferSource();
    source.buffer = buffer;
    
    const bovFilter = this.ctx.createBiquadFilter();
    bovFilter.type = 'bandpass';
    bovFilter.frequency.value = 1500;
    bovFilter.Q.value = 2;
    
    const bovGain = this.ctx.createGain();
    bovGain.gain.value = 0.15;
    
    source.connect(bovFilter);
    bovFilter.connect(bovGain);
    bovGain.connect(this.masterGain!);
    source.start();
  }

  // Public control methods
  setRPM(rpm: number): void {
    this.state.targetRpm = Math.max(600, Math.min(rpm, this.config?.quick.redline || 8000));
  }

  setThrottle(throttle: number): void {
    const prev = this.state.throttle;
    this.state.throttle = Math.max(0, Math.min(1, throttle));
    
    // Calculate target RPM from throttle
    if (this.config) {
      const idleRpm = 800;
      const maxRpm = this.config.quick.redline;
      this.state.targetRpm = idleRpm + (maxRpm - idleRpm) * this.state.throttle;
    }

    // Trigger BOV on throttle lift
    if (prev > 0.5 && throttle < 0.2 && this.state.boost > 5) {
      this.triggerBOV();
    }
  }

  setLoad(load: number): void {
    this.state.load = Math.max(0, Math.min(1, load));
  }

  getState(): PlaybackState {
    return { ...this.state };
  }

  getContext(): AudioContext | null {
    return this.ctx;
  }

  getAnalyser(): AnalyserNode | null {
    return this.analyserNode;
  }

  // Recording for export
  startRecording(): void {
    if (!this.destinationNode) return;
    
    this.recordedChunks = [];
    this.mediaRecorder = new MediaRecorder(this.destinationNode.stream, {
      mimeType: 'audio/webm;codecs=opus',
    });
    
    this.mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) {
        this.recordedChunks.push(e.data);
      }
    };
    
    this.mediaRecorder.start(100); // Collect data every 100ms
  }

  async stopRecording(): Promise<Blob> {
    return new Promise((resolve) => {
      if (!this.mediaRecorder) {
        resolve(new Blob());
        return;
      }
      
      this.mediaRecorder.onstop = () => {
        const blob = new Blob(this.recordedChunks, { type: 'audio/webm' });
        resolve(blob);
      };
      
      this.mediaRecorder.stop();
    });
  }

  // Generate WAV buffer for export (offline rendering)
  async renderOffline(config: EngineConfiguration, durationSec: number, options?: {
    normalize?: boolean;
    sampleRate?: number;
  }): Promise<AudioBuffer> {
    const sampleRate = options?.sampleRate || 44100;
    const length = sampleRate * durationSec;
    const offlineCtx = new OfflineAudioContext(2, length, sampleRate);

    // Create offline audio graph similar to real-time
    const masterGain = offlineCtx.createGain();
    masterGain.gain.value = 0.7;
    masterGain.connect(offlineCtx.destination);

    const compressor = offlineCtx.createDynamicsCompressor();
    compressor.threshold.value = -6;
    compressor.ratio.value = 4;
    compressor.connect(masterGain);

    // Generate combustion buffer procedurally
    const combustionBuffer = this.generateCombustionBuffer(
      offlineCtx, config, durationSec, sampleRate
    );
    
    const source = offlineCtx.createBufferSource();
    source.buffer = combustionBuffer;
    source.connect(compressor);
    source.start();

    const rendered = await offlineCtx.startRendering();

    // Apply normalization if requested
    if (options?.normalize) {
      this.normalizeBuffer(rendered);
    }

    return rendered;
  }

  private generateCombustionBuffer(
    ctx: OfflineAudioContext,
    config: EngineConfiguration,
    duration: number,
    sampleRate: number
  ): AudioBuffer {
    const length = Math.floor(sampleRate * duration);
    const buffer = ctx.createBuffer(2, length, sampleRate);
    const left = buffer.getChannelData(0);
    const right = buffer.getChannelData(1);

    const { quick, forcedInduction } = config;
    const firingIntervals = this.calculateFiringIntervals(
      quick.cylinderCount, quick.crankshaft, quick.layout
    );

    let crankAngle = 0;
    let nextFireTime = firingIntervals[0];
    let currentCylinder = 0;
    let timeSinceLastFire = 0;
    let seed = config.seed || 42;

    const rpm = 800; // Start at idle, could ramp up
    const rampRate = (quick.redline - 800) / (duration * sampleRate * 0.8);

    let currentRpm = rpm;

    for (let i = 0; i < length; i++) {
      // Ramp RPM over duration
      if (i < length * 0.8) {
        currentRpm = Math.min(quick.redline, 800 + rampRate * i);
      } else {
        currentRpm = Math.max(800, currentRpm - rampRate * 0.5);
      }

      const samplesPerRev = (60 * sampleRate) / currentRpm;
      const degreesPerSample = 720 / samplesPerRev;
      
      crankAngle += degreesPerSample;
      timeSinceLastFire += 1 / sampleRate;

      // Fire cylinder
      if (crankAngle >= nextFireTime) {
        currentCylinder = (currentCylinder + 1) % quick.cylinderCount;
        nextFireTime += firingIntervals[currentCylinder % firingIntervals.length];
        timeSinceLastFire = 0;
      }

      if (crankAngle >= 720) {
        crankAngle -= 720;
        nextFireTime -= 720;
      }

      // Combustion pulse
      const t = timeSinceLastFire;
      const throttle = Math.min(1, currentRpm / quick.redline);
      const pulseDecay = 0.001 + 0.002 * (1 - throttle);
      const pulseIntensity = 0.3 + 0.7 * throttle;
      const pulse = Math.exp(-t / pulseDecay) * pulseIntensity;

      // Harmonics
      const freq = currentRpm / 60;
      const phase = i * freq * 2 * Math.PI / sampleRate;
      const harmonics = Math.sin(phase) * 0.3 + Math.sin(phase * 2) * 0.2 + Math.sin(phase * 0.5) * 0.4;

      let sample = pulse * (0.5 + harmonics * 0.5);

      // Mechanical noise
      seed = (seed * 1664525 + 1013904223) & 0xFFFFFFFF;
      const noise = ((seed >>> 0) / 4294967296 - 0.5) * 0.02;
      sample += noise;

      // Soft clip
      sample = Math.tanh(sample * 1.5) * 0.8;

      left[i] = sample;
      right[i] = sample * 0.95 + noise * 0.05; // Slight stereo variation
    }

    return buffer;
  }

  private normalizeBuffer(buffer: AudioBuffer): void {
    let maxAmp = 0;
    for (let ch = 0; ch < buffer.numberOfChannels; ch++) {
      const data = buffer.getChannelData(ch);
      for (let i = 0; i < data.length; i++) {
        maxAmp = Math.max(maxAmp, Math.abs(data[i]));
      }
    }

    if (maxAmp > 0 && maxAmp < 0.95) {
      const gain = 0.95 / maxAmp;
      for (let ch = 0; ch < buffer.numberOfChannels; ch++) {
        const data = buffer.getChannelData(ch);
        for (let i = 0; i < data.length; i++) {
          data[i] *= gain;
        }
      }
    }
  }

  // Convert AudioBuffer to WAV Blob
  audioBufferToWav(buffer: AudioBuffer): Blob {
    const numChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const format = 1; // PCM
    const bitDepth = 16;
    
    const bytesPerSample = bitDepth / 8;
    const blockAlign = numChannels * bytesPerSample;
    const dataSize = buffer.length * blockAlign;
    const headerSize = 44;
    const totalSize = headerSize + dataSize;
    
    const arrayBuffer = new ArrayBuffer(totalSize);
    const view = new DataView(arrayBuffer);
    
    // WAV header
    this.writeString(view, 0, 'RIFF');
    view.setUint32(4, totalSize - 8, true);
    this.writeString(view, 8, 'WAVE');
    this.writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true); // fmt chunk size
    view.setUint16(20, format, true);
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * blockAlign, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitDepth, true);
    this.writeString(view, 36, 'data');
    view.setUint32(40, dataSize, true);
    
    // Interleave channels and write samples
    const channels: Float32Array[] = [];
    for (let ch = 0; ch < numChannels; ch++) {
      channels.push(buffer.getChannelData(ch));
    }
    
    let offset = 44;
    for (let i = 0; i < buffer.length; i++) {
      for (let ch = 0; ch < numChannels; ch++) {
        let sample = channels[ch][i];
        // Clipping protection
        sample = Math.max(-1, Math.min(1, sample));
        const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
        view.setInt16(offset, intSample, true);
        offset += 2;
      }
    }
    
    return new Blob([arrayBuffer], { type: 'audio/wav' });
  }

  private writeString(view: DataView, offset: number, str: string): void {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  }

  destroy(): void {
    this.stop();
    if (this.turboOsc) {
      this.turboOsc.stop();
      this.turboOsc.disconnect();
    }
    if (this.superchargerOsc) {
      this.superchargerOsc.stop();
      this.superchargerOsc.disconnect();
    }
    if (this.ctx) {
      this.ctx.close();
      this.ctx = null;
    }
    this.isInitialized = false;
  }
}

// Singleton instance
let engineInstance: AudioEngine | null = null;

export function getAudioEngine(): AudioEngine {
  if (!engineInstance) {
    engineInstance = new AudioEngine();
  }
  return engineInstance;
}
