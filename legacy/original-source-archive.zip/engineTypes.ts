/** Engine layout types */
export type EngineLayout = 'inline' | 'v' | 'flat' | 'w' | 'radial';

/** Crankshaft character types */
export type CrankshaftType = 'cross-plane' | 'flat-plane' | 'even-fire' | 'odd-fire';

/** Aspiration types */
export type AspirationType = 'na' | 'turbo' | 'supercharged';

/** Turbo size presets */
export type TurboSize = 'small' | 'balanced' | 'large' | 'custom';

/** Supercharger types */
export type SuperchargerType = 'roots' | 'twin-screw' | 'centrifugal';

/** Exhaust routing types */
export type ExhaustRouting = 'single' | 'dual' | 'open-headers';

/** Header geometry types */
export type HeaderGeometry = 'equal-length' | 'unequal-length';

/** Intake types */
export type IntakeType = 'single-throttle-body' | 'itbs' | 'carb' | 'velocity-stacks' | 'airbox';

/** Rev limiter types */
export type RevLimiterType = 'soft' | 'hard-fuel-cut' | 'hard-ignition-cut';

/** Exhaust character presets */
export type ExhaustCharacter = 'stock' | 'sport' | 'race' | 'straight-pipe';

/** Idle character presets */
export type IdleCharacter = 'smooth' | 'lumpy' | 'aggressive' | 'lopey';

/**
 * Quick Build configuration — simplified high-impact controls.
 */
export interface QuickBuildConfig {
  layout: EngineLayout;
  cylinderCount: number;
  displacement: number; // in liters
  crankshaft: CrankshaftType;
  aspiration: AspirationType;
  exhaustCharacter: ExhaustCharacter;
  idleCharacter: IdleCharacter;
  redline: number; // RPM
}

/**
 * Forced induction configuration.
 */
export interface ForcedInductionConfig {
  type: AspirationType;
  // Turbo settings
  turboSize?: TurboSize;
  turboSpoolThreshold?: number; // RPM where boost begins
  maxBoost?: number; // PSI
  bovEnabled?: boolean;
  wastegateEnabled?: boolean;
  // Supercharger settings
  superchargerType?: SuperchargerType;
  superchargerBoost?: number;
  whineIntensity?: number; // 0-1
}

/**
 * Advanced Build configuration — detailed mechanical controls.
 */
export interface AdvancedConfig {
  bore: number; // mm
  stroke: number; // mm
  bankAngle: number; // degrees
  firingOrder: number[];
  headerGeometry: HeaderGeometry;
  exhaustRouting: ExhaustRouting;
  intakeType: IntakeType;
  revLimiterType: RevLimiterType;
  revLimiterRpm: number;
}

/**
 * Full engine configuration combining all settings.
 */
export interface EngineConfiguration {
  // Quick Build params
  quick: QuickBuildConfig;
  // Advanced params (optional, overrides quick defaults)
  advanced?: Partial<AdvancedConfig>;
  // Forced induction
  forcedInduction: ForcedInductionConfig;
  // Runtime state (not saved, used for playback)
  seed?: number; // For deterministic reproduction
}

/**
 * Playback state for the audio engine.
 */
export interface PlaybackState {
  isPlaying: boolean;
  rpm: number;
  throttle: number; // 0-1
  load: number; // 0-1
  targetRpm: number;
  boost: number; // PSI, 0 for NA
}

/**
 * Default Quick Build configuration.
 */
export const DEFAULT_ENGINE_CONFIG: EngineConfiguration = {
  quick: {
    layout: 'v',
    cylinderCount: 8,
    displacement: 5.0,
    crankshaft: 'cross-plane',
    aspiration: 'na',
    exhaustCharacter: 'sport',
    idleCharacter: 'lumpy',
    redline: 6500,
  },
  forcedInduction: {
    type: 'na',
  },
};

/**
 * Factory presets for common engine types.
 */
export const FACTORY_PRESETS: Record<string, { name: string; description: string; config: EngineConfiguration }> = {
  'v8-crossplane': {
    name: 'American V8',
    description: 'Classic cross-plane V8 with a deep, burbling exhaust note',
    config: {
      quick: {
        layout: 'v',
        cylinderCount: 8,
        displacement: 5.7,
        crankshaft: 'cross-plane',
        aspiration: 'na',
        exhaustCharacter: 'sport',
        idleCharacter: 'lumpy',
        redline: 6500,
      },
      forcedInduction: { type: 'na' },
    },
  },
  'v8-flatplane': {
    name: 'Flat-Plane V8',
    description: 'High-revving flat-plane V8 with a screaming, even exhaust note',
    config: {
      quick: {
        layout: 'v',
        cylinderCount: 8,
        displacement: 4.0,
        crankshaft: 'flat-plane',
        aspiration: 'na',
        exhaustCharacter: 'race',
        idleCharacter: 'smooth',
        redline: 8500,
      },
      forcedInduction: { type: 'na' },
    },
  },
  'inline-6': {
    name: 'Inline Six',
    description: 'Smooth, naturally balanced inline-6 with a refined exhaust tone',
    config: {
      quick: {
        layout: 'inline',
        cylinderCount: 6,
        displacement: 3.0,
        crankshaft: 'even-fire',
        aspiration: 'na',
        exhaustCharacter: 'sport',
        idleCharacter: 'smooth',
        redline: 7000,
      },
      forcedInduction: { type: 'na' },
    },
  },
  'inline-4-turbo': {
    name: 'Turbo Inline-4',
    description: 'Rally-inspired turbocharged 4-cylinder with spool and BOV',
    config: {
      quick: {
        layout: 'inline',
        cylinderCount: 4,
        displacement: 2.0,
        crankshaft: 'even-fire',
        aspiration: 'turbo',
        exhaustCharacter: 'sport',
        idleCharacter: 'smooth',
        redline: 7500,
      },
      forcedInduction: {
        type: 'turbo',
        turboSize: 'balanced',
        turboSpoolThreshold: 3000,
        maxBoost: 18,
        bovEnabled: true,
        wastegateEnabled: true,
      },
    },
  },
  'v12': {
    name: 'V12 Grand Tourer',
    description: 'Silky smooth V12 with a rich, complex exhaust note',
    config: {
      quick: {
        layout: 'v',
        cylinderCount: 12,
        displacement: 6.5,
        crankshaft: 'even-fire',
        aspiration: 'na',
        exhaustCharacter: 'sport',
        idleCharacter: 'smooth',
        redline: 8000,
      },
      forcedInduction: { type: 'na' },
    },
  },
  'flat-6': {
    name: 'Flat Six',
    description: 'Air-cooled character flat-6 with distinctive boxer rumble',
    config: {
      quick: {
        layout: 'flat',
        cylinderCount: 6,
        displacement: 3.8,
        crankshaft: 'even-fire',
        aspiration: 'na',
        exhaustCharacter: 'sport',
        idleCharacter: 'lumpy',
        redline: 7400,
      },
      forcedInduction: { type: 'na' },
    },
  },
  'v10': {
    name: 'V10 Supercar',
    description: 'High-revving V10 with an exotic, screaming exhaust note',
    config: {
      quick: {
        layout: 'v',
        cylinderCount: 10,
        displacement: 5.2,
        crankshaft: 'flat-plane',
        aspiration: 'na',
        exhaustCharacter: 'race',
        idleCharacter: 'aggressive',
        redline: 8500,
      },
      forcedInduction: { type: 'na' },
    },
  },
  'supercharged-v8': {
    name: 'Supercharged V8',
    description: 'Roots-blown V8 with supercharger whine and massive torque',
    config: {
      quick: {
        layout: 'v',
        cylinderCount: 8,
        displacement: 6.2,
        crankshaft: 'cross-plane',
        aspiration: 'supercharged',
        exhaustCharacter: 'race',
        idleCharacter: 'aggressive',
        redline: 6800,
      },
      forcedInduction: {
        type: 'supercharged',
        superchargerType: 'roots',
        superchargerBoost: 12,
        whineIntensity: 0.7,
      },
    },
  },
};

/**
 * Get default firing order for a given layout and cylinder count.
 */
export function getDefaultFiringOrder(layout: EngineLayout, cylinderCount: number, crankshaft: CrankshaftType): number[] {
  // Common firing orders
  const firingOrders: Record<string, number[]> = {
    'inline-4': [1, 3, 4, 2],
    'inline-6': [1, 5, 3, 6, 2, 4],
    'v-8-cross-plane': [1, 8, 4, 3, 6, 5, 7, 2],
    'v-8-flat-plane': [1, 5, 4, 8, 3, 7, 2, 6],
    'flat-4': [1, 4, 3, 2],
    'flat-6': [1, 6, 2, 4, 3, 5],
    'v-6': [1, 4, 2, 5, 3, 6],
    'v-10': [1, 6, 5, 10, 2, 7, 3, 8, 4, 9],
    'v-12': [1, 7, 5, 11, 3, 9, 6, 12, 2, 8, 4, 10],
  };

  const key = layout === 'v' && cylinderCount === 8
    ? `v-8-${crankshaft === 'cross-plane' ? 'cross-plane' : 'flat-plane'}`
    : `${layout}-${cylinderCount}`;

  if (firingOrders[key]) return firingOrders[key];

  // Generate sequential firing order as fallback
  return Array.from({ length: cylinderCount }, (_, i) => i + 1);
}

/**
 * Validate a firing order for a given cylinder count.
 */
export function validateFiringOrder(firingOrder: number[], cylinderCount: number): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (firingOrder.length !== cylinderCount) {
    errors.push(`Firing order must have exactly ${cylinderCount} entries, got ${firingOrder.length}`);
  }

  const seen = new Set<number>();
  for (const cyl of firingOrder) {
    if (cyl < 1 || cyl > cylinderCount) {
      errors.push(`Cylinder ${cyl} is out of range (1-${cylinderCount})`);
    }
    if (seen.has(cyl)) {
      errors.push(`Cylinder ${cyl} appears more than once`);
    }
    seen.add(cyl);
  }

  for (let i = 1; i <= cylinderCount; i++) {
    if (!seen.has(i)) {
      errors.push(`Cylinder ${i} is missing from the firing order`);
    }
  }

  return { valid: errors.length === 0, errors };
}
